/* =========================================================
   FIREBASE
========================================================= */

import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";

import {
    getToken,
    initializeAppCheck,
    ReCaptchaEnterpriseProvider
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app-check.js";

import {
    getAuth,
    createUserWithEmailAndPassword,
     signInWithEmailAndPassword,
     GoogleAuthProvider,
     signInWithPopup,
     sendEmailVerification
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

import {
    getFirestore,
    doc,
    getDoc,
    setDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";


/* =========================================================
   FIREBASE CONFIG
========================================================= */

const firebaseConfig = {

    apiKey:
        "AIzaSyBU75WYp5ioaMD1LrNcDyAvROFW2wrTil0",

    authDomain:
        "nexusnova-6ade2.firebaseapp.com",

    projectId:
        "nexusnova-6ade2",

    storageBucket:
        "nexusnova-6ade2.firebasestorage.app",

    messagingSenderId:
        "49791194817",

    appId:
        "1:49791194817:web:07f28326e0f15979536640",

    measurementId:
        "G-YLPFKWSS12"
};


/* =========================================================
   START FIREBASE
========================================================= */

const app =
    initializeApp(firebaseConfig);

/*
   App Check site keys are public, but must be provisioned in Firebase Console.
   Leave the HTML meta value blank until a production Enterprise key and every
   serving origin have been registered. Callable features then fail clearly.
*/
const appCheckSiteKey = String(
    document.querySelector('meta[name="nexusnova-app-check-site-key"]')
        ?.getAttribute("content") || ""
).trim();

let nexusAppCheck = null;
let nexusAppCheckStatus;

if(!appCheckSiteKey){
    nexusAppCheckStatus = {
        ready:false,
        message:"App Check is not configured. Add the production site key before using secure account actions."
    };
    console.warn("NexusNova App Check is not configured.");
}else{
    try{
        nexusAppCheck = initializeAppCheck(
            app,
            {
                provider:new ReCaptchaEnterpriseProvider(appCheckSiteKey),
                isTokenAutoRefreshEnabled:true
            }
        );
        nexusAppCheckStatus = {ready:true,message:""};
    }catch(error){
        console.error("NexusNova App Check initialization:",error);
        nexusAppCheckStatus = {
            ready:false,
            message:"App Check could not be initialized. Check the configured site key and allowed domain."
        };
    }
}

window.nexusAppCheckReady = Promise.resolve(nexusAppCheckStatus);
window.nexusRequireAppCheck = async function(){
    const status = await window.nexusAppCheckReady;

    if(!status?.ready || !nexusAppCheck){
        throw new Error(status?.message || "App Check is unavailable.");
    }

    try{
        const token = await getToken(nexusAppCheck,false);
        if(!token?.token) throw new Error("No App Check token was returned.");
        return token;
    }catch(error){
        console.warn("NexusNova App Check token:",error);
        throw new Error(
            "App Check could not obtain a token. Check the configured site key and allowed domain."
        );
    }
};

const auth =
    getAuth(app);

const db =
    getFirestore(app);

const googleProvider =
    new GoogleAuthProvider();


/* =========================================================
   ELEMENTS
========================================================= */

const emailInput =
    document.getElementById("email");

const passwordInput =
    document.getElementById("password");

const captchaInput =
    document.getElementById("captchaInput");

const captchaBox =
    document.getElementById("captchaBox");

const captchaQuestion =
    document.getElementById("captchaQuestion");

const authBtn =
    document.getElementById("authBtn");

const googleLoginBtn =
    document.getElementById("googleLoginBtn");

const toggleBtn =
    document.getElementById("toggleBtn");

const title =
    document.getElementById("title");

const subtitle =
    document.getElementById("subtitle");

const message =
    document.getElementById("message");


/* =========================================================
   MODE
========================================================= */

let loginMode = false;


/* =========================================================
   CAPTCHA
========================================================= */

let correctAnswer = 0;


function createCaptcha() {

    const num1 =
        Math.floor(Math.random() * 9) + 1;

    const num2 =
        Math.floor(Math.random() * 9) + 1;

    correctAnswer =
        num1 + num2;

    captchaQuestion.textContent =
        `Solve: ${num1} + ${num2} =`;

    captchaInput.value = "";
}


createCaptcha();


/* =========================================================
   MESSAGE
========================================================= */

function showMessage(text, success = false) {

    message.textContent = String(text || "");
    message.style.color = success ? "#22c55e" : "#ef4444";
}


/* =========================================================
   CREATE FIRESTORE USER
========================================================= */

async function createUserProfile(user, name = "") {

    const userRef =
        doc(db, "users", user.uid);

    const userSnap =
        await getDoc(userRef);


    /* Already exists */

    if (userSnap.exists()) {
        return;
    }

    const profileName = String(
        name || user.displayName || "Miner User"
    ).trim().slice(0, 80) || "Miner User";
    const profileEmail = String(user.email || "").trim().slice(0, 320);


    /* Create user */

    await setDoc(
        userRef,
        {

            uid:
                user.uid,

            name:
                profileName,

            email:
                profileEmail,

            balance:
                0,

            totalMined:
                0,

            tasksCompleted:
                0,

            completedTasks:
                {},

            miningActive:
                false,

            miningStartedAt:
                0,

            miningLastUpdate:
                0,

            sessionEarned:
                0,

            lastDailyReward:
                0,

            dailyRewardStreak:
                0,

            createdAt:
                serverTimestamp()

        }
    );

}


/* =========================================================
   GO TO PAGE 2
========================================================= */

function openDashboard(successMessage = "Login successful! Opening dashboard...") {

    showMessage(
        successMessage,
        true
    );

    setTimeout(() => {

        window.location.replace(
            "./page2.html"
        );

    }, 500);

}


/* =========================================================
   LOGIN / SIGNUP SWITCH
========================================================= */

toggleBtn.addEventListener(
    "click",
    () => {

        loginMode =
            !loginMode;

        message.innerHTML = "";

        emailInput.value = "";
        passwordInput.value = "";
        captchaInput.value = "";


        if (loginMode) {

            title.textContent =
                "Welcome Back";

            subtitle.textContent =
                "Log in to your account";

            authBtn.textContent =
                "Log in with Email";

            captchaBox.style.display =
                "none";

            toggleBtn.textContent =
                "Don't have an account? Sign up";

        } else {

            title.textContent =
                "NexusNova";

            subtitle.textContent =
                "Sign up to start mining";

            authBtn.textContent =
                "Sign up with Email";

            captchaBox.style.display =
                "flex";

            toggleBtn.textContent =
                "Already have an account? Log in";

            createCaptcha();

        }

    }
);


/* =========================================================
   EMAIL LOGIN / SIGNUP
========================================================= */

authBtn.addEventListener(
    "click",
    async () => {

        const email =
            emailInput.value.trim();

        const password =
            passwordInput.value;


        if (!email || !password) {

            showMessage(
                "Please enter your email and password."
            );

            return;
        }


        if (password.length < 6) {

            showMessage(
                "Password must contain at least 6 characters."
            );

            return;
        }


        /* CAPTCHA ONLY FOR SIGNUP */

        if (!loginMode) {

            const answer =
                Number(captchaInput.value);

            if (
                !captchaInput.value ||
                answer !== correctAnswer
            ) {

                showMessage(
                    "Incorrect CAPTCHA. Please try again."
                );

                createCaptcha();

                return;
            }

        }


        authBtn.disabled = true;


        if (loginMode) {

            authBtn.textContent =
                "Logging in...";

        } else {

            authBtn.textContent =
                "Creating account...";

        }


        try {


            /* =================================================
               LOGIN
            ================================================= */

            if (loginMode) {

                const result =
                    await signInWithEmailAndPassword(
                        auth,
                        email,
                        password
                    );


                /*
                   IMPORTANT:
                   If old account has no Firestore profile,
                   create it now.
                */

                await createUserProfile(
                    result.user
                );


                openDashboard();

                return;
            }


            /* =================================================
               SIGNUP
            ================================================= */

            const result =
                await createUserWithEmailAndPassword(
                    auth,
                    email,
                    password
                );

            try {
                await sendEmailVerification(result.user);
            } catch (verificationError) {
                console.warn("EMAIL VERIFICATION ERROR:", verificationError);
            }


            /* Create Firestore profile */

            await createUserProfile(
                result.user
            );


            openDashboard(
                "Account created. Check your email to verify it before using rewards. Opening dashboard..."
            );


        } catch (error) {

            console.error(
                "AUTH ERROR:",
                error
            );


            let errorText =
                "Something went wrong. Please try again.";


            if (
                error.code ===
                "auth/email-already-in-use"
            ) {

                errorText =
                    "This email is already registered. Please use Login.";

            }

            else if (
                error.code ===
                "auth/invalid-credential"
            ) {

                errorText =
                    "Incorrect email or password.";

            }

            else if (
                error.code ===
                "auth/invalid-email"
            ) {

                errorText =
                    "Please enter a valid email address.";

            }

            else if (
                error.code ===
                "auth/weak-password"
            ) {

                errorText =
                    "Password must contain at least 6 characters.";

            }

            else if (
                error.code ===
                "auth/network-request-failed"
            ) {

                errorText =
                    "Internet connection problem.";

            }

            else if (
                error.code ===
                "permission-denied"
            ) {

                errorText =
                    "Firebase Firestore permission denied. Check Firestore rules.";

            }

            else {

                errorText =
                    error.message || errorText;

            }


            showMessage(
                errorText
            );


            authBtn.disabled =
                false;


            authBtn.textContent =
                loginMode
                    ? "Log in with Email"
                    : "Sign up with Email";

        }

    }
);


/* =========================================================
   GOOGLE LOGIN
========================================================= */

googleLoginBtn.addEventListener(
    "click",
    async () => {

        googleLoginBtn.disabled =
            true;

        googleLoginBtn.textContent =
            "Connecting to Google...";


        try {

            const result =
                await signInWithPopup(
                    auth,
                    googleProvider
                );


            /*
               IMPORTANT:
               Create Firestore profile for Google user
               if it does not already exist.
            */

            await createUserProfile(
                result.user
            );


            openDashboard();


        } catch (error) {

            console.error(
                "GOOGLE ERROR:",
                error
            );


            let errorText =
                error.message ||
                "Google login failed.";


            if (
                error.code ===
                "auth/popup-closed-by-user"
            ) {

                errorText =
                    "Google login was cancelled.";

            }

            else if (
                error.code ===
                "auth/popup-blocked"
            ) {

                errorText =
                    "Browser blocked Google popup. Allow popups.";

            }

            else if (
                error.code ===
                "auth/unauthorized-domain"
            ) {

                errorText =
                    "This StackBlitz domain is not authorized in Firebase.";

            }

            else if (
                error.code ===
                "permission-denied"
            ) {

                errorText =
                    "Firestore permission denied. Check Firestore rules.";

            }


            showMessage(
                errorText
            );


            googleLoginBtn.disabled =
                false;

            googleLoginBtn.innerHTML = `
                <svg
                    width="18"
                    height="18"
                    viewBox="0 0 48 48"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        fill="#EA4335"
                        d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />

                    <path
                        fill="#4285F4"
                        d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />

                    <path
                        fill="#FBBC05"
                        d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 2.56 34.78l7.97-6.19z"
                    />

                    <path
                        fill="#34A853"
                        d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.46-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                </svg>

                Continue with Google
            `;

        }

    }
);
